const con_into = document.getElementById("con_into");

const btn_con_into = document.getElementById("btn_con_into");
btn_con_into.addEventListener("click", (event) => {
    chrome.storage.local.set({
        con_into: con_into.value
    });

    chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icon-notif.jpg',
        title: 'Information',
        message: 'Option Saved!',
        priority: 2
    }, () => {
        console.log('notif jalan');
    });
});

chrome.storage.local.get(["con_into"], (res) => {
    if(res.con_into === undefined) {
        con_into.value = "+:07:00";
    } else {
        con_into.value = res.con_into;
    }
});