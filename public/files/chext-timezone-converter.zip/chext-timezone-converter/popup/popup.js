const con_from = document.getElementById("con_from");
const con_time = document.getElementById("con_time");
const result_time = document.getElementById("result_time");
const label_result_time = document.getElementById("label_result_time");

con_from.addEventListener("change", () => conTime());
con_time.addEventListener("change", () => conTime());

let con_into, split_con_into;
chrome.storage.local.get(["con_into"], (res) => {
    if(res.con_into === undefined) {
        con_into = "+:07:00";
    } else {
        con_into = res.con_into;
    }
    split_con_into = con_into.split(":");
});

function conTime() {
    let split_con_form = con_from.value.split(":");
    let split_con_time = con_time.value.split(":");
    let result_hour, result_hour_additional, result_minutes, convt_hour = parseInt(split_con_into[1]), convt_sign = split_con_into[0], convt_minutes = parseInt(split_con_into[2]);

    //console.log(split_con_form);
    //console.log(split_con_time);
    /*
        ['+', '02', '00']
        ['11', '10']
    */

    //Hitung Jam nya ----------------------- (Begin)
    if(split_con_form[0] === "+")
        result_hour = parseInt(split_con_time[0]) - parseInt(split_con_form[1]);
    else
        result_hour = parseInt(split_con_time[0]) + parseInt(split_con_form[1]);

    if(convt_sign === "+")
        result_hour = result_hour + convt_hour;
    else
        result_hour = result_hour - convt_hour;

    if(result_hour > 24) result_hour = result_hour - 24;
    if(result_hour < 0) result_hour = 24 - Math.abs(result_hour);
    //Hitung Jam nya ----------------------- (End)


    //Hitung Menit nya ----------------------- (Begin)
    if(split_con_form[0] === "+")
        result_minutes = parseInt(split_con_time[1]) - parseInt(split_con_form[2]);
    else
        result_minutes = parseInt(split_con_time[1]) + parseInt(split_con_form[2]);

    if(convt_sign === "+")
        result_minutes = result_minutes + convt_minutes;
    else
        result_minutes = result_minutes - convt_minutes;

    if(result_minutes > 59) {
        result_hour = result_hour + 1;
        result_minutes = result_minutes - 60;
    }
    if(result_minutes < 0) {
        result_hour = result_hour - 1;
        result_minutes = 60 - Math.abs(result_minutes);
    }
    //Hitung Menit nya ----------------------- (End)


    if (result_hour.toString().length == 1) {
        result_hour = "0" + result_hour;
    }
    if (result_minutes.toString().length == 1) {
        result_minutes = "0" + result_minutes;
    }
    result_time.value = result_hour+':'+result_minutes;
    label_result_time.innerHTML = con_into;
}